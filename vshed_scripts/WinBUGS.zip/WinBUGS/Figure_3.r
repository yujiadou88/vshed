#
# R syntax to reproduce information for Figure 3 from:
#
# Lau LLH, Cowling BJ, Fang VJ, Chan KH, Lau EHY, et al.
# Viral shedding and clinical illness in naturally acquired influenza virus infections
# JID, 2010 (in press).
#
# Last updated by Vicky Fang and Lincoln Lau
# Jan 30, 2010

# new model - set t0 fixed, t = day from symptom onset (2 of 7) of that member
#           - set b fixed for everybody
#           - separate flu A and B

setwd("C:\\WinBUGS")
dir <- "http://sph.hku.hk/data/HongKongNPIstudyV4/"
source("http://www.hku.hk/bcowling/influenza/Vshed_scripts/JID_dataframe.r")

hchar <- read.csv(paste(dir, "hchar_h.csv", sep=""))
clinic <- read.csv(paste(dir, "clinicdat_h.csv", sep=""))

# Flu A
plotdata <- merge(plotdata, clinic[c(2,13)], all.x=T)
dataA <- plotdata[plotdata$QVres==1,-10]

# day from ARI onset
dataA <- merge(dataA,hchar[c(1,7:9)],all.x=T)
v1_day <- dataA$v1_day
dataA$v1_day <- dataA$v1_day-dataA$any_onset-v1_day
dataA$v2_day <- dataA$v2_day-dataA$any_onset-v1_day
dataA$v3_day <- dataA$v3_day-dataA$any_onset-v1_day


# clean the data
dataA$V1[dataA$V1<900] <- dataA$V2[dataA$V2<900] <- dataA$V3[dataA$V3<900] <- 900
dataA$V1 <- log10(dataA$V1)
dataA$V2 <- log10(dataA$V2)
dataA$V3 <- log10(dataA$V3)
dataA$censor.1 <- 1*(dataA$V1==log10(900)) 
dataA$censor.2 <- 1*(dataA$V2==log10(900)) 
dataA$censor.3 <- 1*(dataA$V3==log10(900)) 

dataA <- dataA[c(1:2,10:12,3,13,4,14,5,15)]
names(dataA)[3:11] <- c("t1","t2","t3","vload1","c1","vload2","c2","vload3","c3")
for (i in 1:nrow(dataA)){
   if (is.na(dataA$vload2[i])){
       dataA$vload2[i] <- dataA$vload3[i]
       dataA$c2[i] <- dataA$c3[i]
       dataA$t2[i] <- dataA$t3[i]
       dataA$vload3[i] <- log10(900)     # negative
       dataA$c3[i] <- 1
       dataA$t3[i] <- 100
   }
   else if (is.na(dataA$vload3[i])){
       dataA$vload3[i] <- log10(900)
       dataA$c3[i] <- 1
       dataA$t3[i] <- 100
   }
}

# data
data <- dataA[dataA$hhID!=79&dataA$hhID!=377,]
N <- nrow(data)
vload1 <- data$vload1
vload2 <- data$vload2
vload3 <- data$vload3
t1 <- data$t1
t2 <- data$t2
t3 <- data$t3
c1 <- data$c1
c2 <- data$c2
c3 <- data$c3
limit <- log10(900)

fitdata <- list("N","vload1","vload2","vload3","t1","t2","t3","c1","c2","c3","limit")

# inits

inits <- function() {
  list (b=abs(rnorm(1,0,1)), m=abs(rnorm(1,5,1)), s=abs(rnorm(1,0,1)), sigma=abs(rnorm(1,0,1)), t0<- runif(1,0,5))
}
parameters <- c("b", "m", "s","t0","sigma", "logL")

set.seed(123452)
vl.sim <- bugs (fitdata, inits, parameters, "lognormal.bug", n.chains=1, n.iter=10000, n.burnin=1000, n.thin=5, n.sims=10000) 


b_est <- vl.sim$summary[1,1]
m_est <- vl.sim$summary[2,1]
s_est <- vl.sim$summary[3,1]
t0_est <- vl.sim$summary[4,1]
sigma_est <- vl.sim$summary[5,1]

vload_est <- plot.t <- rep(NA,)
for (j in 1:321){
      plot.t[j] <- (j-1)/10-2
      vload_est[j] <- exp(b_est)/((plot.t[j]+t0_est)*s_est)*exp(-s_est^2*(log((plot.t[j]+t0_est)/m_est))^2)
}
vload_est[is.na(vload_est)] <- 0

# calculate the proportions

# ~VL

## start of functions ##
area_est <- function(startp, stopp, interval){
   n <- (stopp-startp)/interval+1
   index <- vload <- rep(NA,n)
   for (i in 1:n){
     index[i] <- startp+interval*(i-1)
     vload[i] <- height2(index[i])
   }
  (2*sum(vload)-height(startp)-height(stopp))*interval/2
}

height <- function(t){
   if(t>-t0_est) est <- 10^(exp(b_est)/((t+t0_est)*s_est)*exp(-s_est^2*(log((t+t0_est)/m_est))^2))
   else est <- 0
   est <- max(est-10,0)
   est
}
## End of functions ##

# 1- cumulative proportion
remain1 <- rep(NA,61)
total <- area_est(-10,100,0.01)
for (i in 1:61){
  remain1[i] <- 1-area_est(-10,(i-1)/10-1,0.01)/total
}

#-------------------------------------------------------------------------------------------------------------

# ~logVL

## start of functions ##
area_est2 <- function(startp, stopp, interval){
   n <- (stopp-startp)/interval+1
   index <- vload <- rep(NA,n)
   for (i in 1:n){
     index[i] <- startp+interval*(i-1)
     vload[i] <- height2(index[i])
   }
  (2*sum(vload)-height2(startp)-height2(stopp))*interval/2
}

height2 <- function(t){
   if(t>-t0_est) est <- exp(b_est)/((t+t0_est)*s_est)*exp(-s_est^2*(log((t+t0_est)/m_est))^2) 
   else est <- 0
   est <- max(est-1,0)
   est
}
## End of functions ##

# 1- cumulative proportion
remain2 <- rep(NA,61)
total <- area_est2(-10,100,0.01)
for (i in 1:61){
  remain2[i] <- 1-area_est2(-10,(i-1)/10-1,0.01)/total
}

#-------------------------------------------------------------------------------------------------------------

# ~step function(900)~0/1

## start of functions ##
area_est3 <- function(startp, stopp, interval){
   n <- (stopp-startp)/interval+1
   index <- vload <- rep(NA,n)
   for (i in 1:n){
     index[i] <- startp+interval*(i-1)
     vload[i] <- height3(index[i])
   }
  (2*sum(vload)-height3(startp)-height3(stopp))*interval/2
}

height3 <- function(t){
   if(t>-t0_est) est <- exp(b_est)/((t+t0_est)*s_est)*exp(-s_est^2*(log((t+t0_est)/m_est))^2)
   else est <- 0
   if(est>log10(900)) stepv <- 1
   else stepv <- 0
   stepv
}
## End of functions ##

# 1- cumulative proportion
remain3 <- rep(NA,61)
total <- area_est3(-10,100,0.01)
for (i in 1:61){
  remain3[i] <- 1-area_est3(-10,(i-1)/10-1,0.01)/total
}

#



# Plot

windows(width=6,height=4)
par(mar=c(4,4,0,0))
plot(-1,-1, axes=FALSE, xlim=c(-1, 5), ylim=c(0, 1), xlab="", ylab="")
    lines(0:60/10-1, remain1, lwd=2)
    lines(0:60/10-1, remain2, lwd=2.2, lty="dashed")
    lines(0:60/10-1, remain3, lwd=2.2, lty="dotted")
    axis(1, pos=0, lwd=1.5, font=1, at=c(-1 ,0, 1, 2, 3, 4, 5), label=c("", "ARI onset", "+1", "+2", "+3", "+4", "+5"), cex.axis=1.2)
    axis(2, pos=-1, lwd=1.5, font=1, at=c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0), 
         label=c("0%","10%","20%","30%","40%","50%","60%","70%","80%","90%","100%"), cex.axis=1.2, las=1, )

    legend (3.5, 1, c("A","B","C"), lwd=1.7, lty=c("solid","dashed","dotted"), cex=1.2, bty="n") 
            
    mtext("Infectiousness remaining", side = 2, line = 2.6, cex=1.15, font=2) 
    mtext("Days after ARI onset", side = 1, line = 1.8, cex=1.15, font=2) 

    
#
# End of script
#

