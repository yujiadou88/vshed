
 Script to reproduce information for Figure 3 from:

 Lau LLH, Cowling BJ, Fang VJ, Chan KH, Lau EHY, et al.
 Viral shedding and clinical illness in naturally acquired influenza virus infections
 JID, 2010 (in press).

 Last updated by Vicky Fang and Lincoln Lau
 Jan 30, 2010


#1. Set up WinBUGS and R2WinBUGS
#2. Download and upzid WinBUGS.zip to your local computer Drive e.g. C:\\.
#3. Set the working directory at the beginning of the R-scripts e.g. as 'setwd("C:\\WinBUGS\\")'.
#4. Use the R scripts (which call the WinBUGS models in the .bug files).